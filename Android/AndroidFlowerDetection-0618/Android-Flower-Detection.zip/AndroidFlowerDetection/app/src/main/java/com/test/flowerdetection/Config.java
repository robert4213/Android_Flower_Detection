package com.test.flowerdetection;

public class Config {
    public static final String IMAGE_DIRECTORY_NAME = "Android File Upload";
}
